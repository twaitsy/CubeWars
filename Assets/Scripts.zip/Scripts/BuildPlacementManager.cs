﻿using UnityEngine;

public class BuildPlacementManager : MonoBehaviour
{
    public static BuildPlacementManager Instance;

    [Header("Selected (Player)")]
    public BuildItemDefinition selectedItem;

    [Header("Construction")]
    public bool useConstructionSites = true;
    public GameObject constructionSitePrefab; // MUST have ConstructionSite component

    [Tooltip("If true, you can only place blueprints when you can afford the full cost right now.")]
    public bool requireAffordToPlace = true;

    [Tooltip("If true, reserves required resources from building storage when placing a construction site.")]
    public bool reserveResourcesForSites = true;

    [Header("Placement Rules")]
    [Tooltip("If true, blocks placement on cells with BuildCellReservation.blockBuildingPlacement.")]
    public bool respectCellReservations = true;

    [Header("Preview (Optional)")]
    public bool showPreview = false;
    public Material previewMaterial;
    [Range(0.05f, 1f)] public float previewAlpha = 0.35f;

    private GameObject previewObj;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    public void SetSelected(BuildItemDefinition item)
    {
        selectedItem = item;
        ClearPreview();
        Debug.Log($"[BuildPlacementManager] Selected: {(item != null ? item.displayName : "None")}");
    }

    public bool TryPlace(BuildGridCell cell)
    {
        if (selectedItem == null) return false;
        return TryPlace(cell, selectedItem);
    }

    public bool CanPlaceAt(Vector3 pos)
    {
        return !Physics.CheckSphere(pos, 1.5f);
    }


    public bool TryPlace(BuildGridCell cell, BuildItemDefinition item)
    {
        if (cell == null || item == null) return false;
        if (cell.isOccupied) return false;

        if (respectCellReservations)
        {
            var res = cell.GetComponent<BuildCellReservation>();
            if (res != null && res.blockBuildingPlacement)
                return false;
        }

        if (item.prefab == null)
        {
            Debug.LogWarning("[BuildPlacementManager] Build item has no prefab assigned.");
            return false;
        }

        // Always enforce "deposited in buildings" if storage manager exists
        if (requireAffordToPlace)
        {
            bool canAfford = false;

            if (TeamStorageManager.Instance != null)
                canAfford = TeamStorageManager.Instance.CanAffordAvailable(cell.teamID, item.costs);
            else if (TeamResources.Instance != null)
                canAfford = TeamResources.Instance.CanAfford(cell.teamID, item.costs);

            if (!canAfford)
                return false;
        }

        Vector3 pos = cell.worldCenter + new Vector3(0f, item.yOffset, 0f);
        Quaternion rot = Quaternion.identity;

        GameObject placed;

        if (useConstructionSites && constructionSitePrefab != null)
        {
            placed = Instantiate(constructionSitePrefab, pos, rot);

            EnsureBuildItemInstance(placed, item);

            var site = placed.GetComponent<ConstructionSite>();
            if (site == null)
            {
                Debug.LogWarning("[BuildPlacementManager] constructionSitePrefab is missing ConstructionSite component.");
                Destroy(placed);
                return false;
            }

            site.Init(cell, cell.teamID, item, reserveResourcesForSites);

            if (!site.InitOK)
            {
                Destroy(placed);
                return false;
            }

            var tv = placed.GetComponent<TeamVisual>();
            if (tv != null)
            {
                tv.teamID = cell.teamID;
                tv.kind = VisualKind.Building;
                tv.Apply();
            }
        }
        else
        {
            // Instant placement (spend immediately from building storage)
            if (TeamResources.Instance != null)
            {
                if (!TeamResources.Instance.CanAfford(cell.teamID, item.costs))
                    return false;

                if (!TeamResources.Instance.Spend(cell.teamID, item.costs))
                    return false;
            }

            placed = Instantiate(item.prefab, pos, rot);

            EnsureBuildItemInstance(placed, item);
            ApplyTeamToPlacedObject(placed, cell.teamID);
        }

        cell.isOccupied = true;
        cell.placedObject = placed;

        return true;
    }

    void EnsureBuildItemInstance(GameObject go, BuildItemDefinition item)
    {
        if (go == null || item == null) return;

        BuildItemInstance bii = go.GetComponent<BuildItemInstance>();
        if (bii == null) bii = go.AddComponent<BuildItemInstance>();
        bii.itemId = item.name;
    }

    void ApplyTeamToPlacedObject(GameObject placed, int teamID)
    {
        if (placed == null) return;

        Building building = placed.GetComponent<Building>();
        if (building != null) building.teamID = teamID;

        Civilian civ = placed.GetComponent<Civilian>();
        if (civ != null) civ.teamID = teamID;

        Unit unit = placed.GetComponent<Unit>();
        if (unit != null) unit.teamID = teamID;

        var sp = placed.GetComponent<ResourceStorageProvider>();
        if (sp != null) sp.teamID = teamID;

        var drop = placed.GetComponent<ResourceDropoff>();
        if (drop != null) drop.teamID = teamID;

        var storage = placed.GetComponent<ResourceStorageContainer>();
        if (storage != null) storage.teamID = teamID;

        TeamVisual tv = placed.GetComponent<TeamVisual>();
        if (tv != null)
        {
            tv.teamID = teamID;
            tv.kind = (building != null) ? VisualKind.Building : VisualKind.Unit;
            tv.Apply();
        }
    }

    // ---------- Optional Preview ----------

    public void ShowPreviewAt(BuildGridCell cell)
    {
        if (!showPreview) return;
        if (cell == null) return;
        if (selectedItem == null) return;
        if (previewMaterial == null) return;

        if (respectCellReservations)
        {
            var res = cell.GetComponent<BuildCellReservation>();
            if (res != null && res.blockBuildingPlacement)
            {
                ClearPreview();
                return;
            }
        }

        Vector3 pos = cell.worldCenter + new Vector3(0f, selectedItem.yOffset, 0f);

        if (previewObj == null)
        {
            previewObj = Instantiate(selectedItem.prefab);
            previewObj.name = "BuildPreview";
            DisableGameplayComponents(previewObj);
            ApplyPreviewMaterial(previewObj);
        }

        previewObj.transform.SetPositionAndRotation(pos, Quaternion.identity);
        previewObj.SetActive(true);
    }

    public void ClearPreview()
    {
        if (previewObj != null)
            previewObj.SetActive(false);
    }

    void DisableGameplayComponents(GameObject go)
    {
        foreach (var c in go.GetComponentsInChildren<Collider>(true))
            c.enabled = false;

        foreach (var mb in go.GetComponentsInChildren<MonoBehaviour>(true))
        {
            if (mb == null) continue;
            if (mb is BuildPlacementManager) continue;
            mb.enabled = false;
        }
    }

    void ApplyPreviewMaterial(GameObject go)
    {
        var renderers = go.GetComponentsInChildren<Renderer>(true);
        foreach (var r in renderers)
        {
            if (r == null) continue;

            Material m = new Material(previewMaterial);
            Color c = m.color;
            c.a = previewAlpha;
            m.color = c;

            r.material = m;
        }
    }
}

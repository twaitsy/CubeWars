﻿using UnityEngine;

[RequireComponent(typeof(AIEconomy))]
[RequireComponent(typeof(AIMilitary))]
[RequireComponent(typeof(AIBuilder))]
[RequireComponent(typeof(AIResourceManager))]

public class AIPlayer : MonoBehaviour
{
    public int teamID;

    public AIDifficulty difficulty = AIDifficulty.Normal;
    public AIPersonality personality = AIPersonality.Balanced;

    float thinkInterval = 2f;
    float timer;

    AIEconomy economy;
    AIMilitary military;
    AIBuilder builder;

    void Awake()
    {
        economy = GetComponent<AIEconomy>();
        military = GetComponent<AIMilitary>();
        builder = GetComponent<AIBuilder>();

        economy.teamID = teamID;
        military.teamID = teamID;
        builder.teamID = teamID;

        economy.personality = personality;
        military.personality = personality;
        builder.personality = personality;

        ApplyDifficulty();
    }

    void ApplyDifficulty()
    {
        switch (difficulty)
        {
            case AIDifficulty.Easy:
                thinkInterval = 3f;
                break;
            case AIDifficulty.Hard:
                thinkInterval = 1.2f;
                break;
            default:
                thinkInterval = 2f;
                break;
        }
    }

    void Update()
    {
        timer -= Time.deltaTime;
        if (timer > 0f) return;

        timer = thinkInterval;

        economy.Tick();
        builder.Tick();
        military.Tick();
    }
}

﻿using UnityEngine;
using UnityEngine.EventSystems;

public class BuildGridCell : MonoBehaviour
{
    [HideInInspector] public int teamID;
    [HideInInspector] public Vector2Int gridCoord;
    [HideInInspector] public Vector3 worldCenter;

    private BuildGridManager manager;
    public bool isOccupied;
    public GameObject placedObject;


    public void Init(BuildGridManager mgr, int t, Vector2Int coord, Vector3 center)
    {
        manager = mgr;
        teamID = t;
        gridCoord = coord;
        worldCenter = center;
    }

    void OnMouseDown()
    {
        if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject())
            return;

        if (manager != null)
            manager.OnCellClicked(this);
    }

}

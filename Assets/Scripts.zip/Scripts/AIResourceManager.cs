﻿using UnityEngine;
using System.Collections.Generic;

public class AIResourceManager : MonoBehaviour
{
    public int teamID;
    public float claimRadius = 35f;
    public int maxWorkersPerNode = 3;

    List<ResourceNode> claimedNodes = new List<ResourceNode>();

    public void Tick()
    {
        ClaimNearbyNodes();
        AssignWorkers();
    }

    void ClaimNearbyNodes()
    {
        ResourceNode[] all = GameObject.FindObjectsOfType<ResourceNode>();

        foreach (var node in all)
        {
            if (node.IsDepleted) continue;
            if (node.IsClaimedByOther(teamID)) continue;
            if (claimedNodes.Contains(node)) continue;

            if (Vector3.Distance(transform.position, node.transform.position) > claimRadius)
                continue;

            node.claimedByTeam = teamID;
            claimedNodes.Add(node);
        }
    }

    void AssignWorkers()
   Attackable threat =
    GetComponent<AIThreatDetector>()
    .DetectThreatNear(node.transform.position);

if (threat != null)
{
    AIMilitary.Instance.DefendLocation(
        node.transform.position
    );
    continue;
}

}

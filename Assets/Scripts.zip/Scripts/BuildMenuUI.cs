﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using UnityEngine;

public class BuildMenuUI : MonoBehaviour
{
    [Serializable]
    public class BuildCategory
    {
        public string name = "Category";
        public Texture2D icon;
        public BuildItemDefinition[] items;
    }

    [Header("Player")]
    public int playerTeamID = 0;

    [Header("Toggle")]
    public bool show = false;
    public KeyCode toggleKey = KeyCode.B;

    [Header("Panel Layout (Top Right)")]
    public int panelWidth = 460;
    public int panelHeight = 420;
    public int marginRight = 12;
    public int marginTop = 12;

    [Header("Catalog Source")]
    public bool autoDiscover = true;
    public string resourcesPath = "BuildItems";
    public bool useManualCatalogWhenAutoDiscoverOff = true;

    [Header("Manual Catalog (optional)")]
    public BuildCategory[] categories;

    [Header("Optional Sync With Grid")]
    public bool trySyncBuildGridVisibility = true;

    [Header("UI")]
    public bool showCosts = true;
    public bool showAffordability = true;

    private int selectedCategoryIndex = 0;
    private Vector2 scroll;
    private string search = "";
    private readonly StringBuilder sb = new StringBuilder(256);

    // IMPORTANT: separate builder for costs so CostString() doesn't wipe the main label builder.
    private readonly StringBuilder costSb = new StringBuilder(128);

    public bool IsVisible => show;

    public void SetVisible(bool visible)
    {
        show = visible;

        if (!show)
        {
            if (BuildPlacementManager.Instance != null)
                BuildPlacementManager.Instance.SetSelected(null);
        }

        if (trySyncBuildGridVisibility)
            TrySyncGrid(show);
    }

    public void ToggleVisible() => SetVisible(!show);

    public void RebuildCatalog()
    {
        if (autoDiscover)
        {
            categories = DiscoverFromResources(resourcesPath);
            selectedCategoryIndex = Mathf.Clamp(selectedCategoryIndex, 0, Mathf.Max(0, categories.Length - 1));
            scroll = Vector2.zero;
        }
    }

    void Start()
    {
        if (autoDiscover) categories = DiscoverFromResources(resourcesPath);
        else if (!useManualCatalogWhenAutoDiscoverOff) categories = new BuildCategory[0];

        selectedCategoryIndex = (categories != null && categories.Length > 0)
            ? Mathf.Clamp(selectedCategoryIndex, 0, categories.Length - 1)
            : 0;

        if (trySyncBuildGridVisibility)
            TrySyncGrid(show);
    }

    void Update()
    {
        if (Input.GetKeyDown(toggleKey))
            ToggleVisible();
    }

    void OnGUI()
    {
        if (!show) return;

        float left = Screen.width - panelWidth - marginRight;
        float top = marginTop;

        Rect panelRect = new Rect(left, top, panelWidth, panelHeight);
        IMGUIInputBlocker.Register(panelRect);

        GUI.Box(panelRect, "BUILD MENU");

        float x = panelRect.x + 10;
        float y = panelRect.y + 24;

        if (categories == null || categories.Length == 0)
        {
            GUI.Label(new Rect(x, y, panelWidth - 20, 20), "No build items found.");
            y += 20;

            if (autoDiscover)
            {
                GUI.Label(new Rect(x, y, panelWidth - 20, 20), $"Resources path: \"{resourcesPath}\"");
                y += 20;
                if (GUI.Button(new Rect(x, y, 160, 22), "Rebuild Catalog"))
                    RebuildCatalog();
            }
            return;
        }

        GUI.Label(new Rect(x, y, 60, 20), "Search:");
        search = GUI.TextField(new Rect(x + 62, y, panelWidth - 20 - 62, 20), search ?? "");
        y += 26;

        float tabH = 28f;
        float tabW = Mathf.Max(90f, (panelWidth - 20) / Mathf.Max(1, Mathf.Min(categories.Length, 4)));
        int maxTabsPerRow = Mathf.Max(1, Mathf.FloorToInt((panelWidth - 20) / tabW));

        int tabIndex = 0;
        while (tabIndex < categories.Length)
        {
            int rowCount = Mathf.Min(maxTabsPerRow, categories.Length - tabIndex);

            for (int i = 0; i < rowCount; i++)
            {
                int idx = tabIndex + i;
                Rect r = new Rect(x + i * tabW, y, tabW - 6, tabH);
                bool isSel = (idx == selectedCategoryIndex);

                bool prev = GUI.enabled;
                GUI.enabled = !isSel;

                string label = categories[idx] != null ? categories[idx].name : "Null";
                if (GUI.Button(r, label))
                {
                    selectedCategoryIndex = idx;
                    scroll = Vector2.zero;
                }

                GUI.enabled = prev;
            }

            y += tabH + 6;
            tabIndex += rowCount;
        }

        selectedCategoryIndex = Mathf.Clamp(selectedCategoryIndex, 0, categories.Length - 1);
        BuildCategory cat = categories[selectedCategoryIndex];

        GUI.Label(new Rect(x, y, panelWidth - 20, 18), $"Category: {cat.name}");
        y += 20;

        Rect listRect = new Rect(x, y, panelWidth - 20, panelRect.yMax - y - 10);
        GUI.Box(listRect, "");

        float innerX = listRect.x + 8;
        float innerY = listRect.y + 8;
        float innerW = listRect.width - 16;
        float innerH = listRect.height - 16;

        Rect viewRect = new Rect(0, 0, innerW - 18, Mathf.Max(innerH, 800));
        scroll = GUI.BeginScrollView(new Rect(innerX, innerY, innerW, innerH), scroll, viewRect);

        float iy = 0f;
        int drawn = 0;

        BuildItemDefinition[] items = (cat != null) ? cat.items : null;
        if (items == null || items.Length == 0)
        {
            GUI.Label(new Rect(0, iy, innerW - 18, 18), "No items in this category.");
            iy += 20;
        }
        else
        {
            for (int i = 0; i < items.Length; i++)
            {
                BuildItemDefinition item = items[i];
                if (item == null) continue;

                if (!string.IsNullOrEmpty(search))
                {
                    string dn = item.displayName ?? item.name;
                    if (dn == null) dn = "";
                    if (dn.IndexOf(search, StringComparison.OrdinalIgnoreCase) < 0)
                        continue;
                }

                bool canAfford = true;
                if (showAffordability)
                {
                    if (TeamStorageManager.Instance != null)
                        canAfford = TeamStorageManager.Instance.CanAffordAvailable(playerTeamID, item.costs);
                    else if (TeamResources.Instance != null)
                        canAfford = TeamResources.Instance.CanAfford(playerTeamID, item.costs);
                }

                string title = item.displayName;
                if (string.IsNullOrEmpty(title)) title = item.name;

                sb.Length = 0;
                sb.Append(title);

                if (showCosts)
                {
                    sb.Append("  ");
                    sb.Append(CostString(item.costs));
                }

                if (showAffordability && !canAfford)
                    sb.Append("  (Need deposited resources)");

                float rowH = 34f;
                Rect btn = new Rect(0, iy, innerW - 18, rowH);

                bool prev = GUI.enabled;
                GUI.enabled = canAfford;

                bool clicked = GUI.Button(btn, sb.ToString());

                GUI.enabled = prev;

                if (clicked && BuildPlacementManager.Instance != null)
                    BuildPlacementManager.Instance.SetSelected(item);

                iy += rowH + 6;
                drawn++;
                if (drawn > 90) break;
            }

            if (drawn == 0)
                GUI.Label(new Rect(0, iy, innerW - 18, 18), "No items match your search.");
        }

        viewRect.height = Mathf.Max(innerH, iy + 10);
        GUI.EndScrollView();

        GUI.Label(new Rect(panelRect.x + 10, panelRect.yMax - 18, panelWidth - 20, 18),
            "Tip: Select a build item, then click a grid cell to place a blueprint.");
    }

    BuildCategory[] DiscoverFromResources(string path)
    {
        BuildItemDefinition[] all = Resources.LoadAll<BuildItemDefinition>(path);
        if (all == null || all.Length == 0) return new BuildCategory[0];

        Dictionary<string, List<BuildItemDefinition>> grouped = new Dictionary<string, List<BuildItemDefinition>>(StringComparer.OrdinalIgnoreCase);

        for (int i = 0; i < all.Length; i++)
        {
            var item = all[i];
            if (item == null) continue;

            string cat = GetCategoryName(item);
            if (string.IsNullOrEmpty(cat)) cat = "Uncategorized";

            if (!grouped.TryGetValue(cat, out var list))
            {
                list = new List<BuildItemDefinition>();
                grouped[cat] = list;
            }
            list.Add(item);
        }

        List<string> catNames = new List<string>(grouped.Keys);
        catNames.Sort(StringComparer.OrdinalIgnoreCase);

        BuildCategory[] result = new BuildCategory[catNames.Count];

        for (int c = 0; c < catNames.Count; c++)
        {
            string name = catNames[c];
            var list = grouped[name];

            list.Sort((a, b) =>
            {
                string an = a != null ? (a.displayName ?? a.name) : "";
                string bn = b != null ? (b.displayName ?? b.name) : "";
                return StringComparer.OrdinalIgnoreCase.Compare(an, bn);
            });

            result[c] = new BuildCategory { name = name, items = list.ToArray() };
        }

        return result;
    }

    string GetCategoryName(BuildItemDefinition item)
    {
        string fromMeta = TryReadStringMember(item, "category")
                       ?? TryReadStringMember(item, "categoryName")
                       ?? TryReadStringMember(item, "Category")
                       ?? TryReadStringMember(item, "CategoryName");

        if (!string.IsNullOrEmpty(fromMeta))
            return fromMeta.Trim();

        string n = item.name ?? "";
        int us = n.IndexOf('_');
        if (us > 0) return n.Substring(0, us).Trim();

        string dn = item.displayName ?? "";
        int colon = dn.IndexOf(':');
        if (colon > 0) return dn.Substring(0, colon).Trim();

        return "Uncategorized";
    }

    string TryReadStringMember(object obj, string memberName)
    {
        if (obj == null) return null;
        Type t = obj.GetType();

        FieldInfo f = t.GetField(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
        if (f != null && f.FieldType == typeof(string))
            return f.GetValue(obj) as string;

        PropertyInfo p = t.GetProperty(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
        if (p != null && p.PropertyType == typeof(string) && p.GetIndexParameters().Length == 0)
        {
            try { return p.GetValue(obj, null) as string; } catch { }
        }

        return null;
    }

    string CostString(ResourceCost[] costs)
    {
        if (costs == null || costs.Length == 0) return "(Free)";

        costSb.Length = 0;
        costSb.Append("[");

        for (int i = 0; i < costs.Length; i++)
        {
            if (i > 0) costSb.Append(", ");
            costSb.Append(costs[i].type);
            costSb.Append(" ");
            costSb.Append(costs[i].amount);
        }

        costSb.Append("]");
        return costSb.ToString();
    }

    void TrySyncGrid(bool visible)
    {
        MonoBehaviour[] behaviours = FindObjectsOfType<MonoBehaviour>();

        for (int i = 0; i < behaviours.Length; i++)
        {
            var mb = behaviours[i];
            if (mb == null) continue;

            Type t = mb.GetType();
            string n = t.Name;

            if (n.IndexOf("BuildGrid", StringComparison.OrdinalIgnoreCase) < 0)
                continue;

            string[] methods = { "SetGridVisible", "SetVisible", "SetShown", "SetShowGrid", "SetBuildMode", "SetEnabled" };

            for (int m = 0; m < methods.Length; m++)
            {
                var mi = t.GetMethod(methods[m], new Type[] { typeof(bool) });
                if (mi != null) { mi.Invoke(mb, new object[] { visible }); return; }
            }
        }
    }
}

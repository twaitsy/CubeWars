﻿using UnityEngine;

public class Farm : Building
{
    [Header("Farm Production")]
    public int level = 1;
    public int maxLevel = 3;

    [Tooltip("Seconds between production ticks.")]
    public float productionInterval = 2f;

    [Header("Per-Level Output (Food per tick)")]
    public int[] foodPerTickByLevel = new int[] { 2, 5, 10 };

    [Header("Upgrade Costs (Gold)")]
    public int[] goldCostByNextLevel = new int[] { 20, 50, 120 };
    // cost to upgrade from level 1->2 uses [0], 2->3 uses [1], etc.

    [Header("Optional: Auto Upgrade")]
    public bool autoUpgrade = false;
    public float autoUpgradeCheckInterval = 2f;

    private float productionTimer;
    private float upgradeTimer;

    protected override void Start()
    {
        base.Start();
        level = Mathf.Clamp(level, 1, maxLevel);
    }

    void Update()
    {
        if (!IsAlive) return;

        ProduceFoodTick();

        if (autoUpgrade)
            AutoUpgradeTick();
    }

    void ProduceFoodTick()
    {
        if (TeamResources.Instance == null) return;

        productionTimer += Time.deltaTime;
        if (productionTimer < productionInterval) return;
        productionTimer = 0f;

        int index = Mathf.Clamp(level - 1, 0, foodPerTickByLevel.Length - 1);
        int foodToProduce = foodPerTickByLevel[index];

        // If no free storage, don't produce (prevents wasting)
        int free = TeamResources.Instance.GetFreeCapacity(teamID, ResourceType.Food);
        if (free <= 0)
            return;

        int accepted = TeamResources.Instance.Deposit(teamID, ResourceType.Food, foodToProduce);

        // Optional: if partially accepted, you can log or just ignore
        if (accepted < foodToProduce)
        {
            // Storage filled up; remaining food is "wasted" (or you can pause production next ticks)
            // Debug.Log($"Team {teamID} Farm could only store {accepted}/{foodToProduce} Food (storage full).");
        }
    }

    void AutoUpgradeTick()
    {
        upgradeTimer += Time.deltaTime;
        if (upgradeTimer < autoUpgradeCheckInterval) return;
        upgradeTimer = 0f;

        TryUpgrade();
    }

    public bool TryUpgrade()
    {
        if (TeamResources.Instance == null) return false;

        if (level >= maxLevel)
            return false;

        int nextLevel = level + 1;
        int costIndex = Mathf.Clamp(level - 1, 0, goldCostByNextLevel.Length - 1);
        int goldCost = goldCostByNextLevel[costIndex];

        // Spend gold to upgrade
        bool paid = TeamResources.Instance.SpendResource(teamID, ResourceType.Gold, goldCost);
        if (!paid) return false;

        level = nextLevel;

        // Simple visual feedback: scale up slightly by level
        float scale = 1f + (level - 1) * 0.15f;
        transform.localScale = new Vector3(scale, scale, scale);

        Debug.Log($"Team {teamID} Farm upgraded to Level {level} (Cost: {goldCost} Gold)");
        return true;
    }
}

﻿using UnityEngine;

public class TeamResources : MonoBehaviour
{
    public static TeamResources Instance;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    public int GetAvailable(int teamID, ResourceType type)
    {
        return TeamStorageManager.Instance.GetAvailable(teamID, type);
    }

    public bool CanAfford(int teamID, ResourceCost[] costs)
    {
        return TeamStorageManager.Instance.CanAffordAvailable(teamID, costs);
    }

    public bool Spend(int teamID, ResourceCost[] costs)
    {
        if (!CanAfford(teamID, costs))
            return false;

        foreach (var c in costs)
        {
            TeamStorageManager.Instance.Withdraw(teamID, c.type, c.amount);
        }
        return true;
    }
}

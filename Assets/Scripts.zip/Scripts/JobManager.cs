﻿using UnityEngine;
using System.Collections.Generic;

public class JobManager : MonoBehaviour
{
    public static JobManager Instance;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    public bool IsCivilianAssigned(Civilian civ)
    {
        return civ != null && civ.HasJob;
    }

    public int CountBuildersOnSite(ConstructionSite site)
    {
        int count = 0;
        foreach (var civ in FindObjectsOfType<Civilian>())
        {
            if (civ.CurrentConstructionSite == site)
                count++;
        }
        return count;
    }
}

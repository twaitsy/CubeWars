﻿using System.Collections.Generic;
using UnityEngine;

public class MultiTeamAIDirector : MonoBehaviour
{
    [Header("Teams")]
    public int teamCount = 6;
    public int playerTeamID = 0;

    [Header("Aggression (random per team)")]
    [Range(0f, 1f)] public float aggressionMin = 0.15f;
    [Range(0f, 1f)] public float aggressionMax = 0.85f;

    [Header("Tick")]
    public float thinkInterval = 3f;
    public int maxBlueprintsPerTeam = 6;

    [Header("Grid Alignment")]
    [Tooltip("Cell size used to compute corridor lines. Must match your BuildGrid cell spacing.")]
    public float cellSize = 2f;

    [Header("Walkways")]
    [Tooltip("Every N cells, reserve a full corridor line for walkway.")]
    public int corridorEvery = 4;
    [Tooltip("Always reserve a cross (main street) through the HQ.")]
    public bool reserveMainCross = true;
    public int mainCrossHalfWidthCells = 0; // 0 => single line

    [Header("Build Items (assign from your catalog)")]
    public BuildItemDefinition stockpileItem;
    public BuildItemDefinition farmItem;
    public BuildItemDefinition turretItem;
    public BuildItemDefinition barracksItem;
    public BuildItemDefinition weaponsFactoryItem;
    public BuildItemDefinition vehicleFactoryItem;

    [Header("Optional Road Visual (pure visuals, not blocking)")]
    public GameObject roadVisualPrefab;
    public float roadVisualYOffset = 0.02f;

    class TeamBrain
    {
        public float aggression;
        public float timer;
        public Vector3 hqPos;
        public Vector3 hqRight;
        public Vector3 hqForward;

        public int extent;
        public int blueprintsActive;
        public bool walkwaysTagged;
        public HashSet<BuildGridCell> roadVisualSpawned = new HashSet<BuildGridCell>();
    }

    private TeamBrain[] brains;

    void Start()
    {
        brains = new TeamBrain[teamCount];
        for (int t = 0; t < teamCount; t++)
        {
            brains[t] = new TeamBrain
            {
                aggression = Random.Range(aggressionMin, aggressionMax),
                timer = Random.Range(0f, thinkInterval)
            };
        }
    }

    void Update()
    {
        if (BuildPlacementManager.Instance == null) return;

        for (int team = 0; team < teamCount; team++)
        {
            if (team == playerTeamID) continue;

            var b = brains[team];
            b.timer += Time.deltaTime;
            if (b.timer < thinkInterval) continue;
            b.timer = 0f;

            if (!TryCacheHQ(team, b))
                continue;

            List<BuildGridCell> cells = GetTeamCells(team);
            if (cells.Count == 0) continue;

            ComputeExtent(cells, b);

            if (!b.walkwaysTagged)
            {
                TagWalkways(cells, b);
                b.walkwaysTagged = true;
            }

            if (roadVisualPrefab != null)
                SpawnRoadVisuals(cells, b);

            b.blueprintsActive = CountActiveConstructionSites(team);
            if (b.blueprintsActive >= maxBlueprintsPerTeam)
                continue;

            ThinkBuild(team, cells, b);
        }
    }

    bool TryCacheHQ(int teamID, TeamBrain b)
    {
        Headquarters[] hqs = FindObjectsOfType<Headquarters>();
        for (int i = 0; i < hqs.Length; i++)
        {
            if (hqs[i] != null && hqs[i].teamID == teamID)
            {
                Transform t = hqs[i].transform;
                b.hqPos = t.position;
                b.hqRight = t.right;
                b.hqForward = t.forward;
                return true;
            }
        }
        return false;
    }

    List<BuildGridCell> GetTeamCells(int teamID)
    {
        BuildGridCell[] all = FindObjectsOfType<BuildGridCell>();
        List<BuildGridCell> result = new List<BuildGridCell>(all.Length / 4);

        for (int i = 0; i < all.Length; i++)
        {
            var c = all[i];
            if (c == null) continue;
            if (c.teamID != teamID) continue;
            result.Add(c);
        }

        return result;
    }

    void ComputeExtent(List<BuildGridCell> cells, TeamBrain b)
    {
        int maxAbs = 1;
        for (int i = 0; i < cells.Count; i++)
        {
            var c = cells[i];
            GetLocalIndices(c.worldCenter, b, out int ix, out int iz);
            maxAbs = Mathf.Max(maxAbs, Mathf.Abs(ix), Mathf.Abs(iz));
        }
        b.extent = maxAbs;
    }

    void TagWalkways(List<BuildGridCell> cells, TeamBrain b)
    {
        for (int i = 0; i < cells.Count; i++)
        {
            var c = cells[i];
            if (c == null) continue;

            GetLocalIndices(c.worldCenter, b, out int ix, out int iz);

            bool corridor = (corridorEvery > 0) && ((Mathf.Abs(ix) % corridorEvery == 0) || (Mathf.Abs(iz) % corridorEvery == 0));

            bool mainCross = false;
            if (reserveMainCross)
            {
                mainCross |= Mathf.Abs(ix) <= mainCrossHalfWidthCells;
                mainCross |= Mathf.Abs(iz) <= mainCrossHalfWidthCells;
            }

            if (corridor || mainCross)
            {
                var res = c.GetComponent<BuildCellReservation>();
                if (res == null) res = c.gameObject.AddComponent<BuildCellReservation>();
                res.reservedForWalkway = true;
                res.blockBuildingPlacement = true;
            }
        }
    }

    void SpawnRoadVisuals(List<BuildGridCell> cells, TeamBrain b)
    {
        for (int i = 0; i < cells.Count; i++)
        {
            var c = cells[i];
            if (c == null) continue;

            var res = c.GetComponent<BuildCellReservation>();
            if (res == null || !res.reservedForWalkway) continue;

            if (b.roadVisualSpawned.Contains(c)) continue;
            b.roadVisualSpawned.Add(c);

            Vector3 p = c.worldCenter + new Vector3(0f, roadVisualYOffset, 0f);
            var road = Instantiate(roadVisualPrefab, p, Quaternion.identity);
            road.name = $"RoadVisual_Team";
            foreach (var col in road.GetComponentsInChildren<Collider>(true))
                col.enabled = false;
        }
    }

    int CountActiveConstructionSites(int teamID)
    {
        ConstructionSite[] sites = FindObjectsOfType<ConstructionSite>();
        int count = 0;
        for (int i = 0; i < sites.Length; i++)
        {
            var s = sites[i];
            if (s == null) continue;
            if (s.teamID != teamID) continue;
            if (s.IsComplete) continue;
            count++;
        }
        return count;
    }

    void ThinkBuild(int teamID, List<BuildGridCell> cells, TeamBrain b)
    {
        // Count buildings by BuildItemDefinition (no dependency on Turret/Stockpile classes)
        int farms = CountTeamByItem(teamID, farmItem);
        int stockpiles = CountTeamByItem(teamID, stockpileItem);
        int turrets = CountTeamByItem(teamID, turretItem);
        int barracks = CountTeamByItem(teamID, barracksItem);
        int weapons = CountTeamByItem(teamID, weaponsFactoryItem);
        int vehicles = CountTeamByItem(teamID, vehicleFactoryItem);

        // Targets scale with aggression
        int targetFarms = 2 + Mathf.RoundToInt(2 * (1f - b.aggression));
        int targetTurrets = 1 + Mathf.RoundToInt(6 * b.aggression);
        int targetBarracks = (b.aggression > 0.45f) ? 1 + Mathf.RoundToInt(2 * b.aggression) : 0;
        int targetWeapons = (b.aggression > 0.60f) ? 1 : 0;
        int targetVehicles = (b.aggression > 0.75f) ? 1 : 0;

        // 1) Ensure stockpile early
        if (stockpiles == 0 && stockpileItem != null)
        {
            TryPlaceNearCenter(teamID, cells, b, stockpileItem);
            return;
        }

        // 2) Economy near centre
        if (farms < targetFarms && farmItem != null)
        {
            TryPlaceNearCenter(teamID, cells, b, farmItem);
            return;
        }

        // 3) Defense on borders
        if (turrets < targetTurrets && turretItem != null)
        {
            TryPlaceOnBorder(teamID, cells, b, turretItem);
            return;
        }

        // 4) Military production
        if (barracks < targetBarracks && barracksItem != null)
        {
            TryPlaceNearCenter(teamID, cells, b, barracksItem);
            return;
        }

        // 5) Weapons factory
        if (weapons < targetWeapons && weaponsFactoryItem != null)
        {
            TryPlaceNearCenter(teamID, cells, b, weaponsFactoryItem);
            return;
        }

        // 6) Vehicle factory
        if (vehicles < targetVehicles && vehicleFactoryItem != null)
        {
            TryPlaceNearCenter(teamID, cells, b, vehicleFactoryItem);
            return;
        }

        // Otherwise keep expanding based on aggression
        if (b.aggression < 0.5f && farmItem != null)
            TryPlaceNearCenter(teamID, cells, b, farmItem);
        else if (turretItem != null)
            TryPlaceOnBorder(teamID, cells, b, turretItem);
    }

    int CountTeamByItem(int teamID, BuildItemDefinition item)
    {
        if (item == null) return 0;

        string id = item.name;
        BuildItemInstance[] all = FindObjectsOfType<BuildItemInstance>();

        int count = 0;
        for (int i = 0; i < all.Length; i++)
        {
            var inst = all[i];
            if (inst == null) continue;
            if (inst.itemId != id) continue;

            int instTeam = GetTeamId(inst.gameObject);
            if (instTeam != teamID) continue;

            // Count finished buildings and construction sites the same (keeps AI stable)
            count++;
        }

        return count;
    }

    int GetTeamId(GameObject go)
    {
        if (go == null) return -1;

        var b = go.GetComponent<Building>();
        if (b != null) return b.teamID;

        var site = go.GetComponent<ConstructionSite>();
        if (site != null) return site.teamID;

        return -1;
    }

    bool TryPlaceNearCenter(int teamID, List<BuildGridCell> cells, TeamBrain b, BuildItemDefinition item)
    {
        BuildGridCell best = null;
        float bestScore = float.MaxValue;

        for (int i = 0; i < cells.Count; i++)
        {
            var c = cells[i];
            if (!IsCellBuildable(c)) continue;

            GetLocalIndices(c.worldCenter, b, out int ix, out int iz);
            int r = Mathf.Max(Mathf.Abs(ix), Mathf.Abs(iz));

            float score = r;
            if (score < bestScore)
            {
                bestScore = score;
                best = c;
            }
        }

        if (best != null)
            return SafePlace(teamID, best, item);

        return false;
    }

    bool TryPlaceOnBorder(int teamID, List<BuildGridCell> cells, TeamBrain b, BuildItemDefinition item)
    {
        BuildGridCell best = null;
        float bestScore = float.MaxValue;

        int borderMin = Mathf.Max(1, b.extent - 1);

        for (int i = 0; i < cells.Count; i++)
        {
            var c = cells[i];
            if (!IsCellBuildable(c)) continue;

            GetLocalIndices(c.worldCenter, b, out int ix, out int iz);
            int r = Mathf.Max(Mathf.Abs(ix), Mathf.Abs(iz));
            if (r < borderMin) continue;

            float score = (c.worldCenter - b.hqPos).sqrMagnitude;

            if (score < bestScore)
            {
                bestScore = score;
                best = c;
            }
        }

        if (best != null)
        {
            var res = best.GetComponent<BuildCellReservation>();
            if (res == null) res = best.gameObject.AddComponent<BuildCellReservation>();
            res.reservedForBorderDefense = true;

            return SafePlace(teamID, best, item);
        }

        return false;
    }

    bool SafePlace(int teamID, BuildGridCell cell, BuildItemDefinition item)
    {
        if (TeamResources.Instance != null && item != null && item.costs != null)
        {
            if (!TeamResources.Instance.CanAfford(teamID, item.costs))
                return false;
        }

        return BuildPlacementManager.Instance.TryPlace(cell, item);
    }

    bool IsCellBuildable(BuildGridCell c)
    {
        if (c == null) return false;
        if (c.isOccupied) return false;

        var res = c.GetComponent<BuildCellReservation>();
        if (res != null && res.blockBuildingPlacement)
            return false;

        return true;
    }

    void GetLocalIndices(Vector3 world, TeamBrain b, out int ix, out int iz)
    {
        Vector3 d = world - b.hqPos;
        float lx = Vector3.Dot(d, b.hqRight);
        float lz = Vector3.Dot(d, b.hqForward);

        ix = Mathf.RoundToInt(lx / Mathf.Max(0.01f, cellSize));
        iz = Mathf.RoundToInt(lz / Mathf.Max(0.01f, cellSize));
    }
}

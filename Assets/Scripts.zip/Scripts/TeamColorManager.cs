﻿using UnityEngine;

public class TeamColorManager : MonoBehaviour
{
    public static TeamColorManager Instance;

    [Header("6 Team Colors (index = teamID)")]
    public Color[] teamColors = new Color[6]
    {
        new Color(0.2f, 0.4f, 1f),  // Team 0 - Blue
        new Color(1f, 0.25f, 0.25f),// Team 1 - Red
        new Color(0.2f, 1f, 0.4f),  // Team 2 - Green
        new Color(1f, 0.85f, 0.2f), // Team 3 - Yellow
        new Color(0.75f, 0.35f, 1f),// Team 4 - Purple
        new Color(0.2f, 1f, 1f)     // Team 5 - Cyan
    };

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    public Color GetTeamColor(int teamID)
    {
        if (teamColors == null || teamColors.Length == 0) return Color.white;
        if (teamID < 0) teamID = 0;
        if (teamID >= teamColors.Length) teamID = teamID % teamColors.Length;
        return teamColors[teamID];
    }

    /// Applies color to all Renderers on this object and its children.
    public void ApplyTeamColor(GameObject obj, int teamID)
    {
        Color c = GetTeamColor(teamID);

        var renderers = obj.GetComponentsInChildren<Renderer>(true);
        foreach (var r in renderers)
        {
            // This instantiates a unique material instance for this renderer at runtime.
            // Good for prototypes; later you can switch to MaterialPropertyBlock for performance.
            if (r.material != null)
                r.material.color = c;
        }
    }
}

﻿using UnityEngine;
using System.Collections.Generic;

public class Barracks : MonoBehaviour
{
    [Header("Owner")]
    public int teamID;

    [Header("Production")]
    public float buildTime = 5f;
    public Unit unitPrefab;
    public ResourceCost[] unitCost;

    // INTERNAL QUEUE
    private readonly Queue<QueueItem> productionQueue = new Queue<QueueItem>();
    float currentTimer;

    struct QueueItem
    {
        public float remaining;
    }

    void Update()
    {
        if (productionQueue.Count == 0)
            return;

        currentTimer -= Time.deltaTime;
        if (currentTimer > 0f)
            return;

        QueueItem item = productionQueue.Peek();
        item.remaining -= Time.deltaTime;

        if (item.remaining <= 0f)
        {
            SpawnUnit();
            productionQueue.Dequeue();

            if (productionQueue.Count > 0)
                currentTimer = productionQueue.Peek().remaining;
        }
        else
        {
            productionQueue.Dequeue();
            productionQueue.Enqueue(item);
        }
    }

    public void EnqueueUnit()
    {
        if (!TeamResources.Instance.CanAfford(teamID, unitCost))
            return;

        TeamResources.Instance.Spend(teamID, unitCost);

        QueueItem item = new QueueItem
        {
            remaining = buildTime
        };

        productionQueue.Enqueue(item);

        if (productionQueue.Count == 1)
            currentTimer = buildTime;
    }

    void SpawnUnit()
    {
        Unit u = Instantiate(
            unitPrefab,
            transform.position + transform.forward * 2f,
            Quaternion.identity
        );
        u.teamID = teamID;
    }

    // ===== READ-ONLY UI ACCESS =====

    public int QueueCount => productionQueue.Count;

    public float CurrentItemRemaining =>
        productionQueue.Count > 0 ? productionQueue.Peek().remaining : 0f;
}

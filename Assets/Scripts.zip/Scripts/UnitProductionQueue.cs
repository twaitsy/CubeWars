﻿using System.Collections.Generic;
using UnityEngine;

public class UnitProductionQueue : MonoBehaviour
{
    class QueueItem
    {
        public UnitDefinition def;
        public float timeRemaining;
    }

    private readonly Queue<QueueItem> queue = new Queue<QueueItem>();
    private QueueItem current;

    public System.Action<UnitDefinition> OnUnitCompleted;

    void Update()
    {
        if (current == null && queue.Count > 0)
            current = queue.Dequeue();

        if (current == null) return;

        current.timeRemaining -= Time.deltaTime;
        if (current.timeRemaining <= 0f)
        {
            OnUnitCompleted?.Invoke(current.def);
            current = null;
        }
    }

    public void Enqueue(UnitDefinition def)
    {
        queue.Enqueue(new QueueItem
        {
            def = def,
            timeRemaining = def.buildTime
        });
    }

    public bool IsBuilding => current != null;
    public float Progress01 =>
        current == null ? 0f : 1f - (current.timeRemaining / current.def.buildTime);

    public string CurrentUnitName =>
        current == null ? "" : current.def.unitName;
}

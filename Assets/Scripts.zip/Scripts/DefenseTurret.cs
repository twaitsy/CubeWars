﻿using UnityEngine;

public class DefenseTurret : Building
{
    [Header("Targeting")]
    public float range = 12f;
    public float scanInterval = 0.2f;
    public LayerMask targetMask; // set to Targetable layer
    public bool canTargetCivilians = true;

    [Header("Fire")]
    public float fireRate = 2f;          // shots per second
    public float damage = 10f;
    public float projectileSpeed = 25f;
    public Transform muzzle;             // assign in prefab
    public TurretProjectile projectilePrefab; // optional (poolable)

    [Header("Aim")]
    public Transform turretHead;         // rotating part (optional)
    public float turnSpeed = 360f;       // degrees per second

    [Header("Simple Attack Flash")]
    public Renderer flashRenderer;       // optional (muzzle mesh or head mesh)
    public float flashSeconds = 0.06f;
    public float flashEmission = 2.0f;

    private float scanTimer;
    private float fireTimer;

    private ITargetable currentTarget;
    private Transform currentTargetTf;

    // NonAlloc buffer (no GC). Increase if you expect lots of targets in range.
    private readonly Collider[] hits = new Collider[64];

    // MaterialPropertyBlock avoids creating per-turret material instances
    private MaterialPropertyBlock mpb;
    private static readonly int EmissionID = Shader.PropertyToID("_EmissionColor");

    protected override void Start()
    {
        base.Start();
        mpb = new MaterialPropertyBlock();
    }

    void Update()
    {
        if (!IsAlive) return;

        scanTimer += Time.deltaTime;
        fireTimer += Time.deltaTime;

        // Reacquire target occasionally (not every frame)
        if (currentTarget == null || !IsValidTarget(currentTarget) || OutOfRange(currentTargetTf))
        {
            if (scanTimer >= scanInterval)
            {
                scanTimer = 0f;
                AcquireTarget();
            }
        }

        if (currentTarget != null && currentTargetTf != null)
        {
            AimAt(currentTargetTf.position);

            // Fire only if aimed roughly at target (optional)
            if (fireTimer >= (1f / Mathf.Max(0.01f, fireRate)))
            {
                fireTimer = 0f;
                Fire();
            }
        }
    }

    void AcquireTarget()
    {
        currentTarget = null;
        currentTargetTf = null;

        int count = Physics.OverlapSphereNonAlloc(transform.position, range, hits, targetMask, QueryTriggerInteraction.Ignore);
        if (count <= 0) return;

        float best = float.MaxValue;
        Collider bestCol = null;

        for (int i = 0; i < count; i++)
        {
            Collider col = hits[i];
            if (col == null) continue;

            // Get ITargetable without allocations
            var targetable = col.GetComponentInParent<ITargetable>();
            if (targetable == null) continue;

            if (!IsValidTarget(targetable)) continue;
            if (!canTargetCivilians && col.GetComponentInParent<Civilian>() != null) continue;

            Transform tf = (targetable as Component)?.transform;
            if (tf == null) continue;

            float d = (tf.position - transform.position).sqrMagnitude;
            if (d < best)
            {
                best = d;
                bestCol = col;
                currentTarget = targetable;
                currentTargetTf = tf;
            }
        }

        // clear buffer refs (optional hygiene)
        for (int i = 0; i < count; i++) hits[i] = null;
    }

    bool IsValidTarget(ITargetable t)
    {
        if (t == null) return false;
        if (!t.IsAlive) return false;
        if (t.TeamID == teamID) return false; // don't shoot own team
        return true;
    }

    bool OutOfRange(Transform tf)
    {
        if (tf == null) return true;
        return (tf.position - transform.position).sqrMagnitude > (range * range);
    }

    void AimAt(Vector3 worldPos)
    {
        if (turretHead == null) return;

        Vector3 dir = worldPos - turretHead.position;
        dir.y = 0f;
        if (dir.sqrMagnitude < 0.001f) return;

        Quaternion targetRot = Quaternion.LookRotation(dir.normalized, Vector3.up);
        turretHead.rotation = Quaternion.RotateTowards(turretHead.rotation, targetRot, turnSpeed * Time.deltaTime);
    }

    void Fire()
    {
        if (currentTargetTf == null) return;

        // Deal damage (direct hit) OR projectile — choose one.
        // If you already have health on units, do direct for max performance:
        var health = currentTargetTf.GetComponentInParent<IHasHealth>();
        if (health != null)
        {
            // Prefer calling a TakeDamage method if you have it on concrete components
            // Example: (health as MonoBehaviour)?.SendMessage("TakeDamage", damage, SendMessageOptions.DontRequireReceiver);

            // If your units/civilians expose TakeDamage(float), call it safely:
            var unit = currentTargetTf.GetComponentInParent<Unit>();
            if (unit != null) unit.TakeDamage(damage);

            var civ = currentTargetTf.GetComponentInParent<Civilian>();
            if (civ != null) civ.TakeDamage(damage);
        }

        // Optional projectile visuals (poolable)
        if (projectilePrefab != null && muzzle != null)
        {
            var proj = TurretProjectilePool.Instance.Spawn(projectilePrefab, muzzle.position, muzzle.rotation);
            proj.Init(teamID, currentTargetTf, damage, projectileSpeed);
        }

        DoFlash();
    }

    void DoFlash()
    {
        if (flashRenderer == null) return;

        // Simple emissive flash via MPB (no new material instances)
        flashRenderer.GetPropertyBlock(mpb);
        mpb.SetColor(EmissionID, Color.white * flashEmission);
        flashRenderer.SetPropertyBlock(mpb);

        CancelInvoke(nameof(ClearFlash));
        Invoke(nameof(ClearFlash), flashSeconds);
    }

    void ClearFlash()
    {
        if (flashRenderer == null) return;
        flashRenderer.GetPropertyBlock(mpb);
        mpb.SetColor(EmissionID, Color.black);
        flashRenderer.SetPropertyBlock(mpb);
    }
}

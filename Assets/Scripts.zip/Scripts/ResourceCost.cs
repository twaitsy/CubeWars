﻿using System;
using UnityEngine;

[Serializable]
public struct ResourceCost
{
    public ResourceType type;
    public int amount;
}

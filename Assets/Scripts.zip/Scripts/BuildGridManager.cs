﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildGridManager : MonoBehaviour
{
    [Header("Player")]
    public int playerTeamID = 0;

    [Header("Toggle")]
    public KeyCode toggleKey = KeyCode.B;

    [Header("Grid Settings")]
    public float cellSize = 2f;
    public int halfExtent = 6;
    public float yOffset = 0.03f;

    [Header("Visuals")]
    public Material cellMaterial;          // Mat_GridCell (blue)
    public Material selectedMaterial;      // Mat_GridCell_Selected (optional)

    [Header("UI")]
    public BuildMenuUI buildMenuUI;

    private bool isVisible = false;

    private readonly List<GameObject> allCells = new List<GameObject>();
    private BuildGridCell selectedCell;

    void Start()
    {
        StartCoroutine(DelayedBuild());
    }

    IEnumerator DelayedBuild()
    {
        yield return null; // wait 1 frame so HQs exist
        BuildAllGrids();

        SetPlayerGridVisible(false);

        if (buildMenuUI != null)
            buildMenuUI.SetVisible(false);
    }

    void Update()
    {
        if (Input.GetKeyDown(toggleKey))
        {
            if (allCells.Count == 0)
                BuildAllGrids();

            isVisible = !isVisible;
            SetPlayerGridVisible(isVisible);

            if (buildMenuUI != null)
                buildMenuUI.SetVisible(isVisible);
        }
    }

    public void BuildAllGrids()
    {
        // Destroy old cells
        for (int i = 0; i < allCells.Count; i++)
            if (allCells[i] != null) Destroy(allCells[i]);

        allCells.Clear();
        selectedCell = null;

        Headquarters[] hqs = FindObjectsOfType<Headquarters>();
        Debug.Log($"[BuildGridManager] Found HQs: {hqs.Length}");

        foreach (var hq in hqs)
        {
            int teamID = 0;

            Building b = hq.GetComponent<Building>();
            if (b != null) teamID = b.teamID;

            BuildGridAroundHQ(hq.transform.position, teamID);
        }

        // After building, ensure non-player grids are never visible/clickable
        EnforceNonPlayerHiddenAndUnclickable();
    }

    void BuildGridAroundHQ(Vector3 hqPos, int teamID)
    {
        Vector3 origin = new Vector3(hqPos.x, yOffset, hqPos.z);

        // Snap origin to global grid so all teams line up in world space
        origin.x = Mathf.Round(origin.x / cellSize) * cellSize;
        origin.z = Mathf.Round(origin.z / cellSize) * cellSize;

        GameObject parent = new GameObject($"BuildGrid_Team{teamID}");
        parent.transform.SetParent(transform, false);

        for (int gx = -halfExtent; gx <= halfExtent; gx++)
        {
            for (int gz = -halfExtent; gz <= halfExtent; gz++)
            {
                Vector3 center = origin + new Vector3(gx * cellSize, 0f, gz * cellSize);

                GameObject cellObj = GameObject.CreatePrimitive(PrimitiveType.Quad);
                cellObj.name = $"Cell_{teamID}_{gx}_{gz}";
                cellObj.transform.SetParent(parent.transform, false);

                // Flat on ground
                cellObj.transform.position = center;
                cellObj.transform.rotation = Quaternion.Euler(90f, 0f, 0f);
                cellObj.transform.localScale = Vector3.one * (cellSize * 0.95f);

                // Collider for click placement (disabled for non-player or occupied)
                Collider col = cellObj.GetComponent<Collider>();
                if (col == null) cellObj.AddComponent<MeshCollider>();

                // Base material
                Renderer r = cellObj.GetComponent<Renderer>();
                if (r != null && cellMaterial != null)
                    r.sharedMaterial = cellMaterial;

                // Attach BuildGridCell
                BuildGridCell cell = cellObj.AddComponent<BuildGridCell>();
                cell.Init(this, teamID, new Vector2Int(gx, gz), center);

                allCells.Add(cellObj);
            }
        }
    }

    void EnforceNonPlayerHiddenAndUnclickable()
    {
        for (int i = 0; i < allCells.Count; i++)
        {
            var go = allCells[i];
            if (go == null) continue;

            var cell = go.GetComponent<BuildGridCell>();
            if (cell == null) continue;

            if (cell.teamID != playerTeamID)
            {
                var r = go.GetComponent<Renderer>();
                if (r != null) r.enabled = false;

                var c = go.GetComponent<Collider>();
                if (c != null) c.enabled = false;
            }
        }
    }

    void SetPlayerGridVisible(bool visible)
    {
        // Show only player-team cells, and only if they are NOT occupied
        for (int i = 0; i < allCells.Count; i++)
        {
            var go = allCells[i];
            if (go == null) continue;

            var cell = go.GetComponent<BuildGridCell>();
            if (cell == null) continue;

            if (cell.teamID == playerTeamID)
            {
                ApplyCellVisibility(cell, visible);
            }
            else
            {
                // Non-player grids always hidden
                var r = go.GetComponent<Renderer>();
                if (r != null) r.enabled = false;

                var c = go.GetComponent<Collider>();
                if (c != null) c.enabled = false;
            }
        }

        // Clear highlight when hiding
        if (!visible && selectedCell != null)
        {
            SetCellMaterial(selectedCell, cellMaterial);
            selectedCell = null;
        }
    }

    void ApplyCellVisibility(BuildGridCell cell, bool gridVisible)
    {
        if (cell == null) return;

        bool showTile = gridVisible && !cell.isOccupied;

        var r = cell.GetComponent<Renderer>();
        if (r != null) r.enabled = showTile;

        // If occupied, disable collider so you can click the building instead
        var c = cell.GetComponent<Collider>();
        if (c != null) c.enabled = showTile;
    }

    public void OnCellClicked(BuildGridCell cell)
    {
        if (!isVisible) return;
        if (cell == null) return;

        // Player-only safety (colliders on non-player are disabled anyway)
        if (cell.teamID != playerTeamID) return;

        // If occupied, do nothing (tile should be hidden anyway)
        if (cell.isOccupied) return;

        // Place selected build item
        if (BuildPlacementManager.Instance != null &&
            BuildPlacementManager.Instance.selectedItem != null)
        {
            if (BuildPlacementManager.Instance.TryPlace(cell))
            {
                // Hide the tile now that it's occupied
                ApplyCellVisibility(cell, isVisible);

                // Clear any highlight
                if (selectedCell != null) SetCellMaterial(selectedCell, cellMaterial);
                selectedCell = null;
                return;
            }
        }

        // Optional tile highlight (only for unoccupied cells)
        if (selectedCell != null && selectedCell != cell)
            SetCellMaterial(selectedCell, cellMaterial);

        selectedCell = cell;

        if (selectedMaterial != null)
            SetCellMaterial(selectedCell, selectedMaterial);
    }

    void SetCellMaterial(BuildGridCell cell, Material mat)
    {
        if (cell == null || mat == null) return;
        var r = cell.GetComponent<Renderer>();
        if (r != null) r.sharedMaterial = mat;
    }
}

﻿public enum CombatStance
{
    TakePoint,
    FollowTarget,
    Defend
}

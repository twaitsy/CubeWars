﻿using UnityEngine;

public class ResourceNode1 : MonoBehaviour
{
    public ResourceType type;
    public int amount = 500;

    [Tooltip("How much a civilian can harvest per gather action")]
    public int harvestPerTick = 10;

    public int Harvest()
    {
        int taken = Mathf.Min(harvestPerTick, amount);
        amount -= taken;

        if (amount <= 0)
        {
            Destroy(gameObject);
        }

        return taken;
    }
}

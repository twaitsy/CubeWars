﻿using UnityEngine;

public class Attackable : MonoBehaviour, IHasHealth
{
    public int teamID;
    public bool isCivilian;

    public float maxHealth = 100f;
    float currentHealth;

    public bool IsAlive => currentHealth > 0;
    public float CurrentHealth => currentHealth;
    public float MaxHealth => maxHealth;
    public bool canBeRepaired = true;

    public bool IsDamaged => IsAlive && currentHealth < maxHealth;

    public void Repair(float amount)
    {
        if (!canBeRepaired || !IsAlive) return;
        currentHealth = Mathf.Min(maxHealth, currentHealth + amount);
    }

    void Awake()
    {
        currentHealth = maxHealth;
    }

    public void TakeDamage(float dmg)
    {
        if (!IsAlive) return;

        currentHealth -= dmg;

        if (AlertManager.Instance != null)
        {
            AlertManager.Instance.Push(
                $"{name} is under attack!"
            );
        }

        if (currentHealth <= 0)
            Die();
    }

    void Die()
    {
        if (AlertManager.Instance != null)
        {
            AlertManager.Instance.Push(
                $"{name} destroyed"
            );
        }

        Destroy(gameObject);
    }
}

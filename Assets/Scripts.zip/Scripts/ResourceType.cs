﻿public enum ResourceType
{
    Food,
    Gold,

    Wood,
    Stone,
    IronOre,
    Coal,
    Copper,
    Silicon,
    Lithium
}

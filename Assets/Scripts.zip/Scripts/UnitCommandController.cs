﻿using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
public class UnitCommandController : MonoBehaviour, ICommandable
{
    public CombatStance stance = CombatStance.Defend;

    [Header("Follow/Defend")]
    public Transform followTarget;
    public float defendRadius = 8f;

    private NavMeshAgent agent;
    private Vector3 defendAnchor;
    private bool hasDefendAnchor;

    void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
    }

    void Update()
    {
        if (stance == CombatStance.FollowTarget && followTarget != null)
        {
            agent.SetDestination(followTarget.position);
        }
        else if (stance == CombatStance.Defend)
        {
            if (!hasDefendAnchor)
            {
                defendAnchor = transform.position;
                hasDefendAnchor = true;
            }

            float d = (transform.position - defendAnchor).sqrMagnitude;
            if (d > defendRadius * defendRadius)
                agent.SetDestination(defendAnchor);
        }
    }

    public void IssueMove(Vector3 worldPos)
    {
        stance = CombatStance.TakePoint;
        followTarget = null;
        hasDefendAnchor = false;
        agent.SetDestination(worldPos);
    }

    public void SetDefendHere()
    {
        stance = CombatStance.Defend;
        followTarget = null;
        defendAnchor = transform.position;
        hasDefendAnchor = true;
    }

    public void SetFollow(Transform target)
    {
        stance = CombatStance.FollowTarget;
        followTarget = target;
        hasDefendAnchor = false;
    }

    public void ClearFollow()
    {
        if (stance == CombatStance.FollowTarget)
            stance = CombatStance.Defend;

        followTarget = null;
        hasDefendAnchor = false;
    }
}

﻿public enum AIDifficulty
{
    Easy,
    Normal,
    Hard
}

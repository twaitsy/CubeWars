﻿using UnityEngine;

public abstract class Building : MonoBehaviour, ITargetable, IHasHealth, IAttackable
{
    [Header("Team")]
    public int teamID;

    [Header("Health")]
    public float maxHealth = 300f;
    public float currentHealth;

    // ITargetable + IAttackable
    public int TeamID => teamID;
    public bool IsAlive => currentHealth > 0;

    // NEW for IAttackable
    public Transform AimPoint => transform;

    // IHasHealth
    public float CurrentHealth => currentHealth;
    public float MaxHealth => maxHealth;

    protected virtual void Start()
    {
        currentHealth = maxHealth;
    }

    public virtual void TakeDamage(float damage)
    {
        if (!IsAlive) return;

        currentHealth -= damage;

        if (currentHealth <= 0f)
        {
            currentHealth = 0f;
            Die();
        }
    }

    protected virtual void Die()
    {
        Destroy(gameObject);
    }
}
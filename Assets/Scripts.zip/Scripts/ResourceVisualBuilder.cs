﻿using UnityEngine;

[ExecuteAlways]
public class ResourceVisualBuilder : MonoBehaviour
{
    public ResourceType type;
    public Material material;
    public bool rebuild;

    void Update()
    {
        if (!rebuild) return;
        rebuild = false;
        Build();
    }

    void Build()
    {
        // Clear children
        for (int i = transform.childCount - 1; i >= 0; i--)
        {
            if (Application.isPlaying)
                Destroy(transform.GetChild(i).gameObject);
            else
                DestroyImmediate(transform.GetChild(i).gameObject);
        }

        switch (type)
        {
            case ResourceType.Wood:
                MakeLogs(5);
                break;
            case ResourceType.Stone:
                MakeCluster(PrimitiveType.Sphere, 4);
                break;
            case ResourceType.IronOre:
                MakeOre();
                break;
            case ResourceType.Silicon:
                MakeShards(5);
                break;
            case ResourceType.Lithium:
                MakeCrystal(1, 4);
                break;
            case ResourceType.Coal:
                MakeCluster(PrimitiveType.Sphere, 5);
                break;
            case ResourceType.Copper:
                MakeCluster(PrimitiveType.Sphere, 6);
                break;
            default:
                MakeCluster(PrimitiveType.Cube, 3);
                break;
        }

        ApplyMaterial();
    }

    void ApplyMaterial()
    {
        if (material == null) return;
        foreach (var r in GetComponentsInChildren<Renderer>())
            r.sharedMaterial = material;
    }

    void MakeLogs(int count)
    {
        for (int i = 0; i < count; i++)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            go.transform.SetParent(transform, false);
            go.transform.localScale = new Vector3(0.6f, 0.35f, 0.6f);
            go.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
            go.transform.localPosition = new Vector3(
                Random.Range(-0.6f, 0.6f),
                0.2f + i * 0.05f,
                Random.Range(-0.6f, 0.6f)
            );
        }
    }

    void MakeCluster(PrimitiveType prim, int count)
    {
        for (int i = 0; i < count; i++)
        {
            var go = GameObject.CreatePrimitive(prim);
            go.transform.SetParent(transform, false);
            go.transform.localScale = Vector3.one * Random.Range(0.6f, 1.2f);
            go.transform.localPosition = new Vector3(
                Random.Range(-0.6f, 0.6f),
                0.4f,
                Random.Range(-0.6f, 0.6f)
            );
        }
    }

    void MakeOre()
    {
        var baseRock = GameObject.CreatePrimitive(PrimitiveType.Cube);
        baseRock.transform.SetParent(transform, false);
        baseRock.transform.localScale = new Vector3(1.4f, 1.0f, 1.2f);
        baseRock.transform.localPosition = new Vector3(0f, 0.5f, 0f);
        baseRock.transform.localRotation = Quaternion.Euler(0f, 25f, 0f);

        for (int i = 0; i < 4; i++)
        {
            var chunk = GameObject.CreatePrimitive(PrimitiveType.Cube);
            chunk.transform.SetParent(transform, false);
            chunk.transform.localScale = Vector3.one * Random.Range(0.2f, 0.35f);
            chunk.transform.localPosition = new Vector3(
                Random.Range(-0.6f, 0.6f),
                Random.Range(0.3f, 0.9f),
                Random.Range(-0.5f, 0.5f)
            );
        }
    }

    void MakeShards(int count)
    {
        for (int i = 0; i < count; i++)
        {
            var shard = GameObject.CreatePrimitive(PrimitiveType.Cube);
            shard.transform.SetParent(transform, false);
            shard.transform.localScale = new Vector3(
                Random.Range(0.15f, 0.25f),
                Random.Range(0.8f, 1.6f),
                Random.Range(0.15f, 0.25f)
            );
            shard.transform.localPosition = new Vector3(
                Random.Range(-0.5f, 0.5f),
                shard.transform.localScale.y * 0.5f,
                Random.Range(-0.5f, 0.5f)
            );
            shard.transform.localRotation = Quaternion.Euler(
                Random.Range(-10f, 10f),
                Random.Range(0f, 360f),
                Random.Range(-10f, 10f)
            );
        }
    }

    void MakeCrystal(int coreCount, int spikeCount)
    {
        for (int i = 0; i < coreCount; i++)
        {
            var core = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            core.transform.SetParent(transform, false);
            core.transform.localScale = Vector3.one * 1.0f;
            core.transform.localPosition = new Vector3(0f, 0.6f, 0f);
        }

        for (int i = 0; i < spikeCount; i++)
        {
            var spike = GameObject.CreatePrimitive(PrimitiveType.Cube);
            spike.transform.SetParent(transform, false);
            spike.transform.localScale = new Vector3(0.12f, 1.2f, 0.12f);
            float angle = i * (360f / spikeCount);
            Vector3 dir = Quaternion.Euler(0f, angle, 0f) * Vector3.forward;
            spike.transform.localPosition = new Vector3(dir.x * 0.5f, 0.8f, dir.z * 0.5f);
            spike.transform.localRotation = Quaternion.LookRotation(dir) * Quaternion.Euler(-20f, 0f, 0f);
        }
    }
}

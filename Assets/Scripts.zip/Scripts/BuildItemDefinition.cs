﻿using UnityEngine;

[CreateAssetMenu(menuName = "CubeWars/Build Item", fileName = "BuildItem_")]
public class BuildItemDefinition : ScriptableObject
{
    [Header("UI")]
    public string displayName = "New Building";
    [TextArea] public string description;
    public Sprite icon;
    public string category = "Economy";

    [Header("Placement")]
    public GameObject prefab;
    public float yOffset = 0f;
    public bool snapRotationToHQ = false;

    [Header("Costs")]
    public ResourceCost[] costs;

    [Header("AI")]
    public AIBuildingPriority aiPriority = AIBuildingPriority.Economy;

}

﻿using UnityEngine;

public interface ICommandable
{
    void IssueMove(Vector3 worldPos);
}

﻿using UnityEngine;

public class SciFiTeamStyler : MonoBehaviour
{
    public static SciFiTeamStyler Instance;

    [Header("Neon Strength")]
    [Range(0f, 6f)] public float emissionStrength = 2.2f;

    [Header("Type Tints")]
    [Range(0f, 1f)] public float civilianLighten = 0.45f;
    [Range(0f, 1f)] public float buildingDarken = 0.35f;

    static readonly int ColorID = Shader.PropertyToID("_Color");
    static readonly int EmissionID = Shader.PropertyToID("_EmissionColor");

    void Awake()
    {
        Instance = this;
    }

    public void Apply(GameObject obj, int teamID, VisualKind kind)
    {
        if (TeamColorManager.Instance == null) return;

        Color team = TeamColorManager.Instance.GetTeamColor(teamID);
        Color baseColor = team;

        // Sci-fi type grading
        if (kind == VisualKind.Civilian) baseColor = Color.Lerp(team, Color.white, civilianLighten);
        if (kind == VisualKind.Building) baseColor = Color.Lerp(team, Color.black, buildingDarken);

        // Emission for bloom/glow
        Color emissive = baseColor * emissionStrength;

        var block = new MaterialPropertyBlock();
        var renderers = obj.GetComponentsInChildren<Renderer>(true);

        foreach (var r in renderers)
        {
            if (r == null) continue;
            r.GetPropertyBlock(block);

            block.SetColor(ColorID, baseColor);
            block.SetColor(EmissionID, emissive);

            r.SetPropertyBlock(block);
        }
    }
}

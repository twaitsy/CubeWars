﻿using System.Collections.Generic;
using UnityEngine;

public class TeamAIBuild : MonoBehaviour
{
    public int teamID = 1;
    public int playerTeamID = 0;

    public BuildCatalog catalog;
    public float buildInterval = 4f;

    [Tooltip("Categories the AI will try in order.")]
    public List<string> categoryPriority = new List<string> { "Economy", "Industry", "Housing", "Tech" };

    private float timer;

    void Update()
    {
        if (teamID == playerTeamID) return;
        if (catalog == null) return;

        timer += Time.deltaTime;
        if (timer < buildInterval) return;
        timer = 0f;

        TryBuildSomething();
    }

    void TryBuildSomething()
    {
        // Find a free cell belonging to this team
        BuildGridCell cell = FindFreeCellForTeam(teamID);
        if (cell == null) return;

        // Pick an affordable item using category priorities
        BuildItemDefinition chosen = ChooseAffordableItem(teamID);
        if (chosen == null) return;

        // Place it
        if (BuildPlacementManager.Instance != null)
            BuildPlacementManager.Instance.TryPlace(cell, chosen);
    }

    BuildGridCell FindFreeCellForTeam(int t)
    {
        // Simple scan: find any BuildGridCell in scene that matches team and not occupied
        // (Later we can optimize by caching per-team lists in BuildGridManager)
        var cells = FindObjectsOfType<BuildGridCell>();
        for (int i = 0; i < cells.Length; i++)
        {
            if (cells[i].teamID == t && !cells[i].isOccupied)
                return cells[i];
        }
        return null;
    }

    BuildItemDefinition ChooseAffordableItem(int t)
    {
        // Try categories in priority order
        foreach (var cat in categoryPriority)
        {
            foreach (var item in catalog.items)
            {
                if (item == null) continue;
                if (!CategoryMatch(item.category, cat)) continue;

                if (TeamResources.Instance == null || TeamResources.Instance.CanAfford(t, item.costs))
                    return item;
            }
        }

        // Otherwise, any affordable item
        foreach (var item in catalog.items)
        {
            if (item == null) continue;
            if (TeamResources.Instance == null || TeamResources.Instance.CanAfford(t, item.costs))
                return item;
        }

        return null;
    }

    bool CategoryMatch(string a, string b)
    {
        string na = string.IsNullOrWhiteSpace(a) ? "" : a.Trim().ToLowerInvariant();
        string nb = string.IsNullOrWhiteSpace(b) ? "" : b.Trim().ToLowerInvariant();
        return na == nb;
    }
}

﻿public enum SkillType
{
    Mining,
    Building,
    Farming,
    Hauling,
    Combat,
    Driving
}

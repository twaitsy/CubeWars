﻿using System.Collections.Generic;
using UnityEngine;

public class TurretProjectilePool : MonoBehaviour
{
    public static TurretProjectilePool Instance;

    private readonly Dictionary<TurretProjectile, Stack<TurretProjectile>> pools =
        new Dictionary<TurretProjectile, Stack<TurretProjectile>>();

    void Awake()
    {
        Instance = this;
    }

    public TurretProjectile Spawn(TurretProjectile prefab, Vector3 pos, Quaternion rot)
    {
        if (!pools.TryGetValue(prefab, out var stack))
        {
            stack = new Stack<TurretProjectile>();
            pools[prefab] = stack;
        }

        TurretProjectile obj = (stack.Count > 0) ? stack.Pop() : Instantiate(prefab);
        obj.transform.SetPositionAndRotation(pos, rot);
        obj.gameObject.SetActive(true);

        // Remember which pool to return to
        obj.prefabKey = prefab;

        return obj;
    }

    public void Despawn(TurretProjectile obj)
    {
        if (obj == null) return;

        obj.gameObject.SetActive(false);

        if (obj.prefabKey != null)
        {
            if (!pools.TryGetValue(obj.prefabKey, out var stack))
            {
                stack = new Stack<TurretProjectile>();
                pools[obj.prefabKey] = stack;
            }
            stack.Push(obj);
        }
        else
        {
            Destroy(obj.gameObject);
        }
    }
}

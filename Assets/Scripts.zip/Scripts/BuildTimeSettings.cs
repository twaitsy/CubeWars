﻿using UnityEngine;

public class BuildTimeSettings : MonoBehaviour
{
    [Tooltip("Seconds of work required to complete construction (per 1 builder at workRate=1).")]
    public float buildSeconds = 6f;

    [Tooltip("Maximum number of builders that can work on this site at once.")]
    public int maxBuilders = 2;

    [Tooltip("Work per second contributed by each builder.")]
    public float workRatePerBuilder = 1f;
}

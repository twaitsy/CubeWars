﻿using UnityEngine;

[CreateAssetMenu(menuName = "CubeWars/Unit Production Definition")]
public class UnitProductionDefinition : ScriptableObject
{
    public string unitName;
    public GameObject unitPrefab;
    public float buildTime = 5f;
    public ResourceCost[] costs;
}

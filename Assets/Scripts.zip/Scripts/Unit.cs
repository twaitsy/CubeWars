﻿using UnityEngine;

public class Unit : MonoBehaviour, IHasHealth, IAttackable
{
    public int teamID;

    [Header("Combat")]
    public bool combatEnabled = true;
    public float attackRange = 5f;
    public float damage = 10f;

    [Header("Health")]
    public float MaxHealth = 100f;
    public float CurrentHealth = 100f;

    // -----------------------------
    // IHasHealth
    // -----------------------------
    float IHasHealth.CurrentHealth => CurrentHealth;
    float IHasHealth.MaxHealth => MaxHealth;

    // -----------------------------
    // IAttackable
    // -----------------------------
    public int TeamID => teamID;
    public bool IsAlive => CurrentHealth > 0f;
    public Transform AimPoint => transform;

    public void TakeDamage(float amount)
    {
        if (!IsAlive) return;

        CurrentHealth -= amount;
        if (CurrentHealth <= 0f)
        {
            CurrentHealth = 0f;
            Die();
        }
    }

    void Die()
    {
        // Future: death animation, cleanup, etc.
        Destroy(gameObject);
    }
}

﻿using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "CubeWars/Build Catalog", fileName = "BuildCatalog")]
public class BuildCatalog : ScriptableObject
{
    public List<string> categoryOrder = new List<string>() { "Economy", "Industry", "Housing", "Defense", "Tech" };
    public List<BuildItemDefinition> items = new List<BuildItemDefinition>();
}

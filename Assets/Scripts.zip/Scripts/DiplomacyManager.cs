﻿using System.Collections.Generic;
using UnityEngine;

public class DiplomacyManager : MonoBehaviour
{
    public static DiplomacyManager Instance;

    private Dictionary<int, HashSet<int>> warMatrix =
        new Dictionary<int, HashSet<int>>();

    void Awake()
    {
        Instance = this;
    }

    public bool AreAtWar(int a, int b)
    {
        if (a == b) return false;
        return warMatrix.ContainsKey(a) && warMatrix[a].Contains(b);
    }

    public void DeclareWar(int a, int b)
    {
        Ensure(a);
        Ensure(b);
        warMatrix[a].Add(b);
        warMatrix[b].Add(a);
    }

    public void MakePeace(int a, int b)
    {
        if (warMatrix.ContainsKey(a)) warMatrix[a].Remove(b);
        if (warMatrix.ContainsKey(b)) warMatrix[b].Remove(a);
    }

    void Ensure(int team)
    {
        if (!warMatrix.ContainsKey(team))
            warMatrix[team] = new HashSet<int>();
    }
}

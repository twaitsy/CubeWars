﻿[System.Serializable]
public class SkirmishConfig
{
    public int aiCount = 3;
    public AIDifficulty difficulty = AIDifficulty.Normal;
    public bool allowAlliances = false;
}

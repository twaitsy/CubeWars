﻿using UnityEngine;

[RequireComponent(typeof(UnitCombatController))]
[RequireComponent(typeof(Attackable))]
public class Turret : MonoBehaviour
{
    [Header("Owner")]
    public int teamID;

    UnitCombatController combat;
    Attackable attackable;

    void Awake()
    {
        combat = GetComponent<UnitCombatController>();
        attackable = GetComponent<Attackable>();

        combat.teamID = teamID;
        attackable.teamID = teamID;
    }

    void Update()
    {
        // Turrets do not move, patrol, or take jobs
        // Combat handled entirely by UnitCombatController
    }
}

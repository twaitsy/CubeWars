﻿using UnityEngine;

public class UnitCombatController : MonoBehaviour
{
    public enum CombatStance
    {
        Hold,
        Guard,
        Aggressive
    }

    [Header("Owner")]
    public int teamID;

    [Header("Combat Stats")]
    public float range = 8f;
    public float damage = 10f;
    public float fireCooldown = 0.75f;

    [Header("Projectile")]
    public Projectile projectilePrefab;
    public Transform muzzle;

    [Header("FX")]
    public GameObject muzzleFlashFX;

    [Header("Stance")]
    public CombatStance stance = CombatStance.Guard;

    [Header("Target Rules")]
    public bool canAttackCivilians = false;

    [Header("Detection")]
    public LayerMask attackableLayers;

    [Header("Runtime")]
    public Attackable currentTarget;

    bool hasManualTarget;
    float fireTimer;

    void Update()
    {
        fireTimer -= Time.deltaTime;

        if (currentTarget == null || !IsValidTarget(currentTarget))
        {
            currentTarget = null;
            hasManualTarget = false;
        }

        if (!hasManualTarget && stance != CombatStance.Hold)
            AcquireTarget();

        if (currentTarget == null)
            return;

        float dist = Vector3.Distance(transform.position, currentTarget.transform.position);
        if (dist > range)
            return;

        if (fireTimer <= 0f)
        {
            Fire();
            fireTimer = fireCooldown;
        }
    }

    void AcquireTarget()
    {
        Collider[] hits = Physics.OverlapSphere(transform.position, range, attackableLayers);

        Attackable best = null;
        float bestDist = float.MaxValue;

        foreach (var hit in hits)
        {
            var atk = hit.GetComponentInParent<Attackable>();
            if (atk == null || !IsValidTarget(atk)) continue;

            float d = Vector3.Distance(transform.position, atk.transform.position);
            if (d < bestDist)
            {
                bestDist = d;
                best = atk;
            }
        }

        currentTarget = best;
    }

    void Fire()
    {
        if (projectilePrefab == null || muzzle == null)
            return;

        // Muzzle flash
        if (muzzleFlashFX != null)
        {
            Instantiate(muzzleFlashFX, muzzle.position, muzzle.rotation);
        }

        // Projectile
        var proj = Instantiate(projectilePrefab, muzzle.position, muzzle.rotation);
        proj.Init(currentTarget, damage, teamID);
    }

    bool IsValidTarget(Attackable a)
    {
        if (a == null || !a.IsAlive) return false;
        if (a.teamID == teamID) return false;

        if (DiplomacyManager.Instance != null &&
            !DiplomacyManager.Instance.AreAtWar(teamID, a.teamID))
            return false;

        if (a.isCivilian && !canAttackCivilians)
            return false;

        return true;
    }

    public void SetManualTarget(Attackable target)
    {
        if (!IsValidTarget(target)) return;
        currentTarget = target;
        hasManualTarget = true;
    }

    public void ClearManualTarget()
    {
        hasManualTarget = false;
        currentTarget = null;
    }

    public void SetStance(CombatStance newStance)
    {
        stance = newStance;
        if (stance == CombatStance.Hold)
            ClearManualTarget();
    }

    public string GetTargetStatus()
    {
        if (currentTarget == null)
            return "None";

        return currentTarget.name +
               (hasManualTarget ? " (Ordered)" : "");
    }
}

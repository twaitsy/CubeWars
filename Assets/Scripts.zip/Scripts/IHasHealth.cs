﻿public interface IHasHealth
{
    float CurrentHealth { get; }
    float MaxHealth { get; }
}

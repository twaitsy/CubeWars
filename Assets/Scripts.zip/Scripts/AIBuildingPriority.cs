﻿public enum AIBuildingPriority
{
    Economy,
    Military,
    Storage
}

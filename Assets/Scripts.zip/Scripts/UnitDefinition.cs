﻿using UnityEngine;

[CreateAssetMenu(menuName = "Units/Unit Definition")]
public class UnitDefinition : ScriptableObject
{
    public string unitName;
    public GameObject prefab;
    public float buildTime;
    public ResourceCost[] costs;
}

﻿using System.Collections.Generic;
using UnityEngine;

public static class IMGUIInputBlocker
{
    private static readonly List<Rect> rects = new List<Rect>(8);
    private static int lastRegisterFrame = -999;

    /// <summary>
    /// Register a panel rect each frame from OnGUI.
    /// </summary>
    public static void Register(Rect r)
    {
        if (Time.frameCount != lastRegisterFrame)
        {
            rects.Clear();
            lastRegisterFrame = Time.frameCount;
        }

        rects.Add(r);
    }

    /// <summary>
    /// Returns true if the mouse is over any registered IMGUI panel.
    /// Works in Update by using last frame's registered rects.
    /// </summary>
    public static bool IsMouseOverUI(Vector3 mouseScreenPos)
    {
        // If no panels have registered recently, don't block anything.
        // During Update, lastRegisterFrame will usually be (Time.frameCount - 1) when visible.
        if (Time.frameCount - lastRegisterFrame > 1)
            return false;

        // Convert screen coords (bottom-left) -> IMGUI coords (top-left)
        Vector2 guiPos = new Vector2(mouseScreenPos.x, Screen.height - mouseScreenPos.y);

        for (int i = 0; i < rects.Count; i++)
        {
            if (rects[i].Contains(guiPos))
                return true;
        }

        return false;
    }
}

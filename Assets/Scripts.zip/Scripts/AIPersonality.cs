﻿public enum AIPersonality
{
    Aggressive,
    Balanced,
    Defensive
}

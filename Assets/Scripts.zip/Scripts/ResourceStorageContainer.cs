﻿using UnityEngine;
using System.Collections.Generic;

public class ResourceStorageContainer : MonoBehaviour
{
    public int teamID;

    Dictionary<ResourceType, int> stored = new Dictionary<ResourceType, int>();
    Dictionary<ResourceType, int> capacity = new Dictionary<ResourceType, int>();

    void Awake()
    {
        foreach (ResourceType t in System.Enum.GetValues(typeof(ResourceType)))
        {
            stored[t] = 0;
            capacity[t] = 0;
        }
    }

    public int GetStored(ResourceType type)
    {
        return stored[type];
    }

    public int GetCapacity(ResourceType type)
    {
        return capacity[type];
    }

    public int Deposit(ResourceType type, int amount)
    {
        int free = capacity[type] - stored[type];
        int accepted = Mathf.Min(free, amount);
        stored[type] += accepted;
        return accepted;
    }

    public int Withdraw(ResourceType type, int amount)
    {
        int taken = Mathf.Min(stored[type], amount);
        stored[type] -= taken;
        return taken;
    }

    public void AddCapacity(ResourceType type, int amount)
    {
        capacity[type] += amount;
    }
}

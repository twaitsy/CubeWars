﻿using UnityEngine;

/// <summary>
/// Attached to placed buildings and construction sites so we can count/identify them
/// without relying on specific script/class names like "Turret" or "Stockpile".
/// </summary>
public class BuildItemInstance : MonoBehaviour
{
    [Tooltip("Matches the BuildItemDefinition asset name (item.name).")]
    public string itemId;
}

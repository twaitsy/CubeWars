﻿using UnityEngine;

public class ResourceStorageProvider : MonoBehaviour
{
    public int teamID;

    [Header("Capacities provided by this building")]
    public ResourceCapacityEntry[] capacities;

    private bool started;
    private bool registered;

    void Start()
    {
        started = true;
        Register();
    }

    void OnEnable()
    {
        // Only register here if Start has already run (prevents wrong-team registration on Instantiate)
        if (started) Register();
    }

    void OnDisable()
    {
        if (registered) Unregister();
    }

    void Register()
    {
        if (registered) return;
        if (TeamResources.Instance == null) return;

        if (capacities != null)
        {
            for (int i = 0; i < capacities.Length; i++)
            {
                int cap = Mathf.Max(0, capacities[i].capacity);
                if (cap > 0)
                    TeamResources.Instance.AddCapacity(teamID, capacities[i].type, cap);
            }
        }

        registered = true;
    }

    void Unregister()
    {
        if (TeamResources.Instance == null) return;

        if (capacities != null)
        {
            for (int i = 0; i < capacities.Length; i++)
            {
                int cap = Mathf.Max(0, capacities[i].capacity);
                if (cap > 0)
                    TeamResources.Instance.RemoveCapacity(teamID, capacities[i].type, cap);
            }
        }

        registered = false;
    }

    /// <summary>
    /// Call this after changing teamID at runtime (e.g., right after Instantiate)
    /// if you ever need it. Not required with the Start-based registration,
    /// but useful for safety.
    /// </summary>
    public void RefreshRegistration()
    {
        if (!started) return;

        if (registered)
            Unregister();

        Register();
    }
}

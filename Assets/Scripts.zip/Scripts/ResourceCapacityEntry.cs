﻿using System;
using UnityEngine;

[Serializable]
public struct ResourceCapacityEntry
{
    public ResourceType type;
    public int capacity;
}

﻿using UnityEngine;

public class BuildCellReservation : MonoBehaviour
{
    public bool reservedForWalkway = true;
    public bool reservedForBorderDefense = false;

    [Tooltip("If true, no buildings can be placed here.")]
    public bool blockBuildingPlacement = true;
}

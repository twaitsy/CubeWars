﻿using UnityEngine;

public class TurretProjectile : MonoBehaviour
{
    // Pool uses this to return the projectile to the correct stack
    [HideInInspector] public TurretProjectile prefabKey;

    private Transform target;
    private float damage;
    private float speed;
    private float life;

    public void Init(int ownerTeamID, Transform targetTf, float dmg, float spd)
    {
        target = targetTf;
        damage = dmg;
        speed = spd;
        life = 2.0f;
    }

    void Update()
    {
        life -= Time.deltaTime;
        if (life <= 0f)
        {
            TurretProjectilePool.Instance.Despawn(this);
            return;
        }

        if (target == null)
        {
            TurretProjectilePool.Instance.Despawn(this);
            return;
        }

        Vector3 dir = target.position - transform.position;
        float dist = dir.magnitude;

        if (dist < 0.25f)
        {
            // Optional: apply damage on "impact"
            // If you want impact damage, tell me what component has TakeDamage(damage)
            TurretProjectilePool.Instance.Despawn(this);
            return;
        }

        transform.position += dir.normalized * (speed * Time.deltaTime);
        transform.forward = dir.normalized;
    }
}

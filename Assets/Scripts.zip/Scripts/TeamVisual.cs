﻿using UnityEngine;

public enum VisualKind { Unit, Civilian, Building }

public class TeamVisual : MonoBehaviour
{
    public int teamID;
    public VisualKind kind = VisualKind.Unit;
    public bool applyOnStart = true;

    void Start()
    {
        if (applyOnStart) Apply();
    }

    public void Apply()
    {
        if (SciFiTeamStyler.Instance != null)
            SciFiTeamStyler.Instance.Apply(gameObject, teamID, kind);
        else if (TeamColorManager.Instance != null)
            TeamColorManager.Instance.ApplyTeamColor(gameObject, teamID); // fallback
    }
}

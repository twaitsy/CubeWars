﻿using UnityEngine;

public class AIEconomy : MonoBehaviour
{
    public int teamID;
    public AIPersonality personality;

    [Header("Behaviour")]
    public float buildDelayMultiplier = 1f;

    Barracks barracks;
    float buildTimer;

    void Start()
    {
        FindBarracks();
    }

    void FindBarracks()
    {
        foreach (var b in GameObject.FindObjectsOfType<Barracks>())
        {
            if (b.teamID == teamID)
            {
                barracks = b;
                return;
            }
        }
    }

    public void Tick()
    {
        if (barracks == null)
        {
            FindBarracks();
            return;
        }

        buildTimer -= Time.deltaTime;
        if (buildTimer > 0f) return;

        var unit = ChooseUnitToBuild();
        if (unit == null) return;

        if (barracks.CanQueue(unit))
        {
            barracks.QueueUnit(unit);
            buildTimer = unit.buildTime * buildDelayMultiplier;
        }
    }

    UnitDefinition ChooseUnitToBuild()
    {
        if (barracks.producibleUnits == null || barracks.producibleUnits.Count == 0)
            return null;

        switch (personality)
        {
            case AIPersonality.Aggressive:
                return barracks.producibleUnits[0]; // cheap / fast

            case AIPersonality.Defensive:
                return barracks.producibleUnits[barracks.producibleUnits.Count - 1]; // strong

            default:
                return barracks.producibleUnits[Random.Range(0, barracks.producibleUnits.Count)];
        }
    }
}

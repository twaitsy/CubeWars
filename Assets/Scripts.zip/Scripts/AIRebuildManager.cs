﻿using UnityEngine;
using System.Collections.Generic;

public class AIRebuildManager : MonoBehaviour
{
    public int teamID;
    Queue<(BuildItemDefinition, Vector3)> rebuildQueue
        = new Queue<(BuildItemDefinition, Vector3)>();

    void OnEnable()
    {
        BuildPlacementManager.OnBuildingDestroyed += OnBuildingLost;
    }

    void OnDisable()
    {
        BuildPlacementManager.OnBuildingDestroyed -= OnBuildingLost;
    }

    void OnBuildingLost(int lostTeam, BuildItemDefinition item, Vector3 pos)
    {
        if (lostTeam != teamID) return;
        rebuildQueue.Enqueue((item, pos));
    }

    public void Tick()
    {
        if (rebuildQueue.Count == 0) return;

        var (item, pos) = rebuildQueue.Peek();

        if (!TeamResources.Instance.CanAfford(teamID, item.costs))
            return;

        if (!BuildPlacementManager.Instance.CanPlaceAt(pos))
            return;

        BuildPlacementManager.Instance.PlaceBuild(
            item, pos, Quaternion.identity, teamID
        );

        rebuildQueue.Dequeue();
    }
}

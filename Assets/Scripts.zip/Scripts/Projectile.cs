﻿using UnityEngine;

public class Projectile : MonoBehaviour
{
    [Header("Combat")]
    public float damage;
    public int sourceTeam;

    [Header("Movement")]
    public float speed = 25f;
    public float maxLifetime = 5f;

    [Header("FX")]
    public GameObject impactFX;

    Attackable target;
    float lifeTimer;

    public void Init(Attackable target, float damage, int teamID)
    {
        this.target = target;
        this.damage = damage;
        this.sourceTeam = teamID;
    }

    void Update()
    {
        lifeTimer += Time.deltaTime;
        if (lifeTimer >= maxLifetime)
        {
            Destroy(gameObject);
            return;
        }

        if (target == null || !target.IsAlive)
        {
            Destroy(gameObject);
            return;
        }

        Vector3 dir = target.transform.position - transform.position;
        float dist = dir.magnitude;

        if (dist < 0.2f)
        {
            HitTarget();
            return;
        }

        transform.position += dir.normalized * speed * Time.deltaTime;
        transform.forward = dir.normalized;
    }

    void HitTarget()
    {
        if (target != null && target.IsAlive)
        {
            target.TakeDamage(damage);

            if (impactFX != null)
            {
                Instantiate(
                    impactFX,
                    target.transform.position + Vector3.up * 0.5f,
                    Quaternion.identity
                );
            }
        }

        Destroy(gameObject);
    }
}

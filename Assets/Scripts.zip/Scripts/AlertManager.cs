﻿using UnityEngine;
using System.Collections.Generic;

public class AlertManager : MonoBehaviour
{
    public static AlertManager Instance;

    class Alert
    {
        public string text;
        public float timer;
    }

    List<Alert> alerts = new List<Alert>();

    void Awake()
    {
        Instance = this;
    }

    void OnGUI()
    {
        float y = Screen.height - 200;

        for (int i = alerts.Count - 1; i >= 0; i--)
        {
            var a = alerts[i];
            a.timer -= Time.deltaTime;

            GUI.Label(new Rect(10, y, 400, 20), a.text);
            y -= 22;

            if (a.timer <= 0)
                alerts.RemoveAt(i);
        }
    }

    public void Push(string text, float duration = 3f)
    {
        alerts.Add(new Alert { text = text, timer = duration });
    }
}

﻿public class ResourceNode : MonoBehaviour
{
    public ResourceType type;
    public int remaining = 500;

    [HideInInspector] public int claimedByTeam = -1;

    public bool IsDepleted => remaining <= 0;

    public bool IsClaimedByOther(int teamID)
    {
        return claimedByTeam != -1 && claimedByTeam != teamID;
    }
}

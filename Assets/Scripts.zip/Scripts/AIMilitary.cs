﻿using UnityEngine;

public class AIMilitary : MonoBehaviour
{
    public int teamID;
    public AIPersonality personality;

    [Header("Attack Rules")]
    public int attackThreshold = 4;
    public float attackRange = 40f;


    public void DefendLocation(Vector3 pos)
    {
        Unit[] units = GameObject.FindObjectsOfType<Unit>();

        foreach (var u in units)
        {
            if (u.teamID != teamID) continue;
            if (!u.combatEnabled) continue;

            u.MoveTo(pos);
            return; // send ONE unit
        }
    }

    public void Tick()
    {
        UnitCombatController[] units = GameObject.FindObjectsOfType<UnitCombatController>();
        int myUnits = 0;

        foreach (var u in units)
            if (u.teamID == teamID)
                myUnits++;

        if (myUnits < attackThreshold)
            return;

        Attackable target = FindEnemyTarget();
        if (target == null) return;

        foreach (var unit in units)
        {
            if (unit.teamID != teamID) continue;

            unit.SetManualTarget(target);
        }
    }

    Attackable FindEnemyTarget()
    {
        Attackable[] all = GameObject.FindObjectsOfType<Attackable>();
        Attackable best = null;
        float bestDist = float.MaxValue;

        foreach (var a in all)
        {
            if (!a.IsAlive) continue;
            if (a.teamID == teamID) continue;

            if (!DiplomacyManager.Instance.AreAtWar(teamID, a.teamID))
                continue;

            float score = Vector3.Distance(transform.position, a.transform.position);

            // Personality bias
            if (personality == AIPersonality.Aggressive && a.isCivilian)
                score *= 0.7f;

            if (personality == AIPersonality.Defensive && !a.isBuilding)
                score *= 1.3f;

            if (score < bestDist && score <= attackRange)
            {
                bestDist = score;
                best = a;
            }
        }

        return best;
    }
}

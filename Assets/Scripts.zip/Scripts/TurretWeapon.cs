﻿using UnityEngine;

[RequireComponent(typeof(UnitCombatController))]
public class TurretWeapon : MonoBehaviour
{
    void Awake()
    {
        // No logic needed — combat handled by UnitCombatController
    }
}

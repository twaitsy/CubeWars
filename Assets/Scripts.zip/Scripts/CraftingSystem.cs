﻿using UnityEngine;

public class CraftingSystem : MonoBehaviour
{
    public static CraftingSystem Instance;

    void Awake()
    {
        Instance = this;
    }

    public bool CraftTool(int teamID, ToolItem item, int amount = 1)
    {
        if (item == null || amount <= 0) return false;
        if (TeamResources.Instance == null || TeamInventory.Instance == null) return false;

        // Spend costs * amount
        if (item.craftCost != null)
        {
            for (int i = 0; i < item.craftCost.Length; i++)
            {
                int need = item.craftCost[i].amount * amount;
                if (TeamResources.Instance.GetStored(teamID, item.craftCost[i].type) < need)
                    return false;
            }

            for (int i = 0; i < item.craftCost.Length; i++)
            {
                int need = item.craftCost[i].amount * amount;
                TeamResources.Instance.SpendResource(teamID, item.craftCost[i].type, need);
            }
        }

        TeamInventory.Instance.AddTool(teamID, item, amount);
        return true;
    }
}

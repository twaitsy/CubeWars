﻿using UnityEngine;
using System.Collections.Generic;

public class ConstructionSite : MonoBehaviour
{
    public int teamID;
    public float buildTime = 10f;
    public ResourceCost[] costs;

    float buildProgress;
    bool completed;

    Dictionary<ResourceType, int> delivered = new Dictionary<ResourceType, int>();

    void Awake()
    {
        foreach (var c in costs)
            delivered[c.type] = 0;
    }

    void Update()
    {
        if (completed)
            return;

        if (!HasAllResources())
            return;

        buildProgress += Time.deltaTime;

        if (buildProgress >= buildTime)
            Complete();
    }

    bool HasAllResources()
    {
        foreach (var c in costs)
        {
            if (delivered[c.type] < c.amount)
                return false;
        }
        return true;
    }

    void Complete()
    {
        completed = true;
        // Final building spawn handled elsewhere
    }

    // ===== UI / QUERY API =====

    public bool IsComplete => completed;

    public float Progress01 =>
        buildTime > 0f ? Mathf.Clamp01(buildProgress / buildTime) : 1f;

    public string GetStatusLine()
    {
        return completed ? "Completed" : "Under Construction";
    }

    public ResourceCost[] GetRequiredCosts()
    {
        return costs;
    }

    public int GetDeliveredAmount(ResourceType type)
    {
        return delivered.TryGetValue(type, out int v) ? v : 0;
    }

    public int AssignedBuilderCount =>
        JobManager.Instance.CountBuildersOnSite(this);

    // ===== RESOURCE DELIVERY =====

    public void Deliver(ResourceType type, int amount)
    {
        if (!delivered.ContainsKey(type))
            delivered[type] = 0;

        delivered[type] += amount;
    }
}
